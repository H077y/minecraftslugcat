local slugcat = models.models.slugcat
local slugcatUpperBody = slugcat.FullBody.UpperBody
local slugcatLowerBody = slugcat.FullBody.LowerBody
return {
    slugcat = slugcat,
    slugcatUpperBody = slugcatUpperBody,
    slugcatLowerBody = slugcatLowerBody
}